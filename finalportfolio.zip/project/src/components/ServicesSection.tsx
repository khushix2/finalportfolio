import React from 'react';
import { 
  Layout, 
  Code, 
  ShoppingBag, 
  Zap, 
  FileCode, 
  Database 
} from 'lucide-react';
import ServiceCard from './ServiceCard';

const ServicesSection: React.FC = () => {
  const services = [
    {
      id: 1,
      title: 'UI/UX Design',
      description: 'Creating beautiful, intuitive interfaces that provide exceptional user experiences.',
      icon: <Layout className="w-6 h-6" />,
      delay: 0
    },
    {
      id: 2,
      title: 'Web Development',
      description: 'Building modern, responsive websites and applications with the latest technologies.',
      icon: <Code className="w-6 h-6" />,
      delay: 100
    },
    {
      id: 3,
      title: 'E-commerce Websites',
      description: 'Developing online stores with secure payment gateways and inventory management.',
      icon: <ShoppingBag className="w-6 h-6" />,
      delay: 200
    },
    {
      id: 4,
      title: 'Optimization',
      description: 'Improving website speed, performance, and search engine rankings.',
      icon: <Zap className="w-6 h-6" />,
      delay: 300
    },
    {
      id: 5,
      title: 'Java Programming',
      description: 'Developing robust backend systems and applications using Java.',
      icon: <Database className="w-6 h-6" />,
      delay: 400
    },
    {
      id: 6,
      title: 'C Programming',
      description: 'Creating efficient, performant applications and system software with C.',
      icon: <FileCode className="w-6 h-6" />,
      delay: 500
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">My Services</h2>
          <div className="w-16 h-1 bg-indigo-500 mx-auto mb-6 rounded-full"></div>
          <p className="text-lg text-gray-600">
            I offer a wide range of services to help businesses establish a strong online presence.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <ServiceCard 
              key={service.id}
              title={service.title}
              description={service.description}
              icon={service.icon}
              delay={service.delay}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;