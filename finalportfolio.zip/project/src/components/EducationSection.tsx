import React from 'react';
import EducationTimeline from './EducationTimeline';

const EducationSection: React.FC = () => {
  const educationItems = [
    {
      id: 1,
      year: '2022 - 2026',
      degree: 'Bachelor of Technology',
      institution: 'MIET College Meerut',
      description: 'Currently pursuing B.Tech with a focus on computer science and engineering fundamentals.',
    },
    {
      id: 2,
      year: '2021 - 2022',
      degree: '12th Standard',
      institution: 'Sacred Heart School, Amritsar',
      description: 'Completed senior secondary education with a focus on science and mathematics.',
    },
    {
      id: 3,
      year: '2019 - 2020',
      degree: '10th Standard',
      institution: 'Sacred Heart School, Amritsar',
      description: 'Completed secondary education with excellence in academics and extracurricular activities.',
    }
  ];

  return (
    <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Education</h2>
          <div className="w-16 h-1 bg-indigo-500 mx-auto mb-6 rounded-full"></div>
          <p className="text-lg text-gray-600">
            My academic journey that has shaped my technical skills and knowledge base.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <EducationTimeline items={educationItems} />
        </div>
      </div>
    </section>
  );
};

export default EducationSection;