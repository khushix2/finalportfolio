import React, { useEffect, useRef } from 'react';
import { ChevronDown } from 'lucide-react';
import AnimatedBackground from './AnimatedBackground';

const HeroSection: React.FC = () => {
  const titleRef = useRef<HTMLHeadingElement>(null);
  
  useEffect(() => {
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let interval: number | null = null;
    
    const animateTitle = () => {
      let iteration = 0;
      
      clearInterval(interval as number);
      
      interval = setInterval(() => {
        if (titleRef.current) {
          titleRef.current.innerText = titleRef.current.dataset.value!
            .split("")
            .map((letter, index) => {
              if (index < iteration) {
                return titleRef.current!.dataset.value![index];
              }
              
              return letters[Math.floor(Math.random() * 26)];
            })
            .join("");
        }
        
        if (titleRef.current && iteration >= titleRef.current.dataset.value!.length) {
          clearInterval(interval as number);
        }
        
        iteration += 1 / 3;
      }, 30) as unknown as number;
    };
    
    animateTitle();
    
    const handleMouseOver = () => {
      animateTitle();
    };

    if (titleRef.current) {
      titleRef.current.addEventListener('mouseover', handleMouseOver);
    }

    return () => {
      if (titleRef.current) {
        titleRef.current.removeEventListener('mouseover', handleMouseOver);
      }
      if (interval) clearInterval(interval);
    };
  }, []);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <AnimatedBackground />
      
      <div className="container mx-auto px-4 z-10 text-center">
        <h2 className="text-indigo-400 text-xl md:text-2xl mb-3 font-light tracking-wider">
          Hello, I'm
        </h2>
        <h1 
          ref={titleRef}
          data-value="KHUSHI SHARMA"
          className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight"
        >
          KHUSHI SHARMA
        </h1>
        <div className="w-16 h-1 bg-indigo-500 mx-auto mb-6 rounded-full"></div>
        <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto">
          A passionate web developer creating beautiful & functional digital experiences
        </p>
        <div className="flex justify-center space-x-4">
          <a 
            href="#contact" 
            className="px-8 py-3 bg-indigo-600 text-white rounded-lg font-medium transition-all duration-300 hover:bg-indigo-700 hover:shadow-lg transform hover:-translate-y-1"
          >
            Contact Me
          </a>
          <a 
            href="#about" 
            className="px-8 py-3 bg-transparent border border-white/30 text-white rounded-lg font-medium transition-all duration-300 hover:bg-white/10 hover:shadow-lg transform hover:-translate-y-1"
          >
            About Me
          </a>
        </div>
      </div>
      
      <a 
        href="#about" 
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-white/70 transition-all hover:text-white animate-bounce"
      >
        <ChevronDown size={32} />
      </a>
    </section>
  );
};

export default HeroSection;