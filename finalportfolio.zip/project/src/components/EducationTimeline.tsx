import React from 'react';
import { GraduationCap } from 'lucide-react';

interface EducationItem {
  id: number;
  year: string;
  degree: string;
  institution: string;
  description: string;
}

interface EducationTimelineProps {
  items: EducationItem[];
}

const EducationTimeline: React.FC<EducationTimelineProps> = ({ items }) => {
  return (
    <div className="relative">
      {/* Vertical line */}
      <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 h-full w-px bg-indigo-200"></div>
      
      {items.map((item, index) => (
        <div 
          key={item.id} 
          className={`mb-12 md:mb-16 relative ${
            index % 2 === 0 ? 'md:pr-8 md:text-right md:ml-auto md:mr-1/2' : 'md:pl-8 md:ml-1/2'
          }`}
        >
          {/* Circle on the timeline */}
          <div 
            className="absolute top-0 left-0 md:left-1/2 transform -translate-x-1/2 md:-translate-x-1/2 w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center shadow-md z-10"
          >
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          
          {/* Content */}
          <div 
            className={`pl-16 md:pl-0 ${
              index % 2 === 0 ? 'md:pr-16' : 'md:pl-16'
            }`}
          >
            <span className="inline-block px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm font-medium mb-2">
              {item.year}
            </span>
            <h3 className="text-xl font-bold text-gray-800 mb-1">{item.degree}</h3>
            <h4 className="text-lg font-medium text-indigo-600 mb-3">{item.institution}</h4>
            <p className="text-gray-600">{item.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default EducationTimeline;