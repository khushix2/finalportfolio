import React from 'react';
import { Code, Palette, Globe } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">About Me</h2>
          <div className="w-16 h-1 bg-indigo-500 mx-auto mb-6 rounded-full"></div>
          <p className="text-lg text-gray-600">
            I'm Khushi Sharma, a passionate web developer from Amritsar, Punjab, India. 
            I create beautiful, functional websites with a focus on user experience and performance.
          </p>
        </div>

        <div className="grid md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-5">
            <div className="relative">
              <div className="bg-indigo-600/90 w-full h-full absolute -bottom-4 -right-4 rounded-xl"></div>
              <div className="relative bg-gray-100 p-2 rounded-xl shadow-lg overflow-hidden">
                <div className="aspect-w-4 aspect-h-5 rounded-lg overflow-hidden">
                  <img 
                    src="https://images.pexels.com/photos/5926382/pexels-photo-5926382.jpeg" 
                    alt="Girl working on laptop" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="md:col-span-7">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Web Developer & UI/UX Designer</h3>
            <p className="text-gray-600 mb-6">
              I'm currently pursuing my B.Tech degree at MIET College Meerut (2022-2026), 
              while actively working on web development projects. With expertise in both front-end and 
              back-end technologies, I build complete web solutions that help businesses thrive online.
            </p>

            <div className="grid sm:grid-cols-3 gap-4 mb-8">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center mb-2">
                  <Code className="w-5 h-5 text-indigo-600 mr-2" />
                  <span className="font-semibold">Development</span>
                </div>
                <p className="text-sm text-gray-600">Modern websites & applications</p>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center mb-2">
                  <Palette className="w-5 h-5 text-indigo-600 mr-2" />
                  <span className="font-semibold">Design</span>
                </div>
                <p className="text-sm text-gray-600">Beautiful & intuitive UI/UX</p>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center mb-2">
                  <Globe className="w-5 h-5 text-indigo-600 mr-2" />
                  <span className="font-semibold">E-commerce</span>
                </div>
                <p className="text-sm text-gray-600">Online store solutions</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">HTML/CSS</span>
              <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">JavaScript</span>
              <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">React</span>
              <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">Java</span>
              <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">C</span>
              <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">UI/UX Design</span>
              <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">Tailwind CSS</span>
              <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">Responsive Design</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;